#!/bin/bash
#SBATCH --job-name=boronphene #×÷ÒµÃû
#SBATCH --nodes=1#$ÚµãÊýÁ¿
#SBATCH --ntasks=20  # Æô¶¯µÄÈÎÎñÊýÁ¿
#SBATCH --ntasks-per-node=20  #Ã¿¸ö$ÚµãÆô¶¯µÄÈÎÎñÊýÁ¿
#SBATCH --time=240:00:00  #×î´óÔËÐÐÊ±¼ä ´ËÊ±ÉèÖÃÎª1day Ò²¿ÉÒÔÉèÖÃ¸ü³¤Ê±¼ä
#SBATCH --partition=CPU1  #ÉèÖÃÔËÐÐµÄ·ÖÇø£¬²»Í¬µÄ·ÖÇøµÄÓ²¼þ²»Í¬£¬Ö¸¶¨²»Í¬ÇøÓòµÄ·þÎñÆ÷
#SBATCH --output=%j.out    #Êä³öÎÄ¼þµÄÎ»ÖÃ
#SBATCH --error=%j.err   #±¨´íÐÅÏ¢Êä³ö
#SBATCH --exclude=comput2,comput14,comput15,comput16,comput17,comput29,comput31,comput28,comput24,comput25,comput30,comput19,comput1,comput18,comput20,comput21,comput22,comput32,comput39
export PATH="/public1/home/jingchao/miniconda3/envs/mtp_env/bin:$PATH"

python -u Run_Lammps_3rd.py

